package com.cg.exmpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.exmpl")
public class ExmplApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExmplApplication.class, args);
	}
}
