package com.cg.exmpl.service;

import com.cg.exmpl.model.Cart;
import com.cg.exmpl.model.CartItem;

public interface CartItemService {

	void addCartItem(CartItem cartItem);
	void removeCartItem(String CartItemId);
	void removeAllCartItems(Cart cart);
}
