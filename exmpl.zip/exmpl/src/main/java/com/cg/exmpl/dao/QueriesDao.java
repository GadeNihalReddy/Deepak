package com.cg.exmpl.dao;

import com.cg.exmpl.model.Queries;

public interface QueriesDao {

 	void addQuery(Queries queries);
}
